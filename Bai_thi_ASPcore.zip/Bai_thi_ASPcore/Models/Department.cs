﻿namespace Bai_thi_ASPcore.Models
{
    public class Department
    {
        public int Id { get; set; }

        public string DepartmentName { get; set; }

        public string DepartmentCode { get; set;}

        public string Location { get; set;}

        public string NumberOfPersonals { get; set;}
    }
}
