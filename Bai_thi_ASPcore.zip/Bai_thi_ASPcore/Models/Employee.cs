﻿namespace Bai_thi_ASPcore.Models
{
    public class Employee
    {
        public int Id { get; set; }

        public string EmployeeName { get; set; }

        public string EmployeeCode { get; set; }

        public string Department { get; set; }

        public string Rank { get; set; }

    }
}
